import { Component, OnInit } from '@angular/core';
import { Iregister } from 'src/app/user/models/iregister';
import { UserService } from 'src/app/user/services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  register: Iregister = {
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  };
  

  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }
  registerSubmit() {
    console.log(this.register);
    this.userService.registerUser(this.register).subscribe(
      (res) => {
        console.log(JSON.stringify(res));
      },
      (err) => console.log(err)
    );
  }

}
