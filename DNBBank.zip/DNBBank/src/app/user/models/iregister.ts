export interface Iregister {
    username: string;
    email: string;
    password: string;
    confirmPassword: string;
}
