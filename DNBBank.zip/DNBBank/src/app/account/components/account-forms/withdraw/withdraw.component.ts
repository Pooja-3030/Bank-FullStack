import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Iwithdraw } from 'src/app/account/models/iwithdraw';
import { AccountService } from 'src/app/account/services/account.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  withdraw1: Iwithdraw = {

    amount: 0

  }

 

  constructor(private accountService: AccountService, private router: Router) { }

 

  withdraw() {

    console.log(this.withdraw1);

    let accountId = JSON.parse(localStorage.getItem('accountDetails')||'').accountId;

    this.accountService.withdraw(accountId,this.withdraw1).subscribe(

      (res) => {

        console.log(res);

        this.router.navigate(['/dashboard']);

      },

      (err) => {

        console.log(err);

      }

    );

  }

 

  ngOnInit(): void {

  }
}
