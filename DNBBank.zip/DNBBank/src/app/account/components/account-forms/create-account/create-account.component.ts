import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Iaccount } from 'src/app/account/models/iaccount';
import { AccountService } from 'src/app/account/services/account.service';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {
account: Iaccount = {
  accountType:'', 
  pan:'',
  aadhar:'',
  mobilenum:'',
  userId : 0,
  balance: 0,
  
  
};

  constructor(private accountService:AccountService,private router: Router ) { }

  ngOnInit(): void {
  }
  CreateAccount(){
    let userId = JSON.parse(localStorage.getItem("userDetails")||'').id;
    this.account.userId = userId;
    console.log(this.account);
    this.accountService.CreateAccount(this.account)
      .subscribe( (res) => {
        // rest call
        console.log(res);
        localStorage.setItem('accountDetails', JSON.stringify(res));
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(err);
      }
      );
    


  }

}
